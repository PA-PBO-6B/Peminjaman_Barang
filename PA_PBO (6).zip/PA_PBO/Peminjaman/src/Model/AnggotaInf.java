/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Database.Database;
/**
 *
 * @author LENOVO
 */


public class AnggotaInf extends Mahasiswa {
    private String departemen_mhs;

    public AnggotaInf(String nim, String nama, String noTelp, String departemen_mhs) {
        super(nim, nama, noTelp);  // Memanggil konstruktor Mahasiswa dengan parameter yang sesuai
        this.departemen_mhs = departemen_mhs;
    }

    public String getDepartemen_mhs() { 
        return departemen_mhs; 
    }
    
    public void setDepartemen_mhs(String departemen_mhs) { 
        this.departemen_mhs = departemen_mhs; 
    }

    @Override
    public String getRoleDescription() {
        return "Anggota Infokom di departemen: " + departemen_mhs;
    }

    // Method untuk mengambil data AnggotaInf berdasarkan NIM
    public static AnggotaInf getAnggotaInfByNIM(String NIM) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = Database.connect();
            String query = "SELECT * FROM anggota_inforsa WHERE NIM_mhs = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, NIM);
            rs = stmt.executeQuery();

            if (rs.next()) {
                String nim = rs.getString("NIM_mhs");  // Mengambil NIM sebagai String
                String nama = rs.getString("Nama_mhs");
                String noTelp = rs.getString("no_telp_mhs");
                String departemen = rs.getString("departemen_mhs");

                return new AnggotaInf(nim, nama, noTelp, departemen); // Menggunakan NIM sebagai String
            } else {
                return null; // Data tidak ditemukan
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) Database.disconnect();
            } catch (SQLException e) {
                System.err.println("Gagal menutup sumber daya: " + e.getMessage());
            }
        }
    }
}
