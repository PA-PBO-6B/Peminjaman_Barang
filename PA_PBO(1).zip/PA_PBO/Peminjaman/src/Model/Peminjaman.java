/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author LENOVO
 */
import Database.Database;
import java.util.Date;

public class Peminjaman {
    private int ID_Peminjaman;
    private Date tanggal_peminjaman;
    private Date tanggal_kembali;
    private int barangKode_brg;
    private int Kuantitas;
    private int mahasiswaNIM_mhs;
    private String Status_peminjaman;

    public Peminjaman(int ID_Peminjaman, Date tanggal_peminjaman, Date tanggal_kembali, int barangKode_brg, int Kuantitas, int mahasiswaNIM_mhs, String Status_peminjaman) {
        this.ID_Peminjaman = ID_Peminjaman;
        this.tanggal_peminjaman = tanggal_peminjaman;
        this.tanggal_kembali = tanggal_kembali;
        this.barangKode_brg = barangKode_brg;
        this.Kuantitas = Kuantitas;
        this.mahasiswaNIM_mhs = mahasiswaNIM_mhs;
        this.Status_peminjaman = Status_peminjaman;
    }

    
    public int getID_Peminjaman() {
        return ID_Peminjaman;
    }

    public void setID_Peminjaman(int ID_Peminjaman) {
        this.ID_Peminjaman = ID_Peminjaman;
    }

    public Date getTanggal_peminjaman() {
        return tanggal_peminjaman;
    }

    public void setTanggal_peminjaman(Date tanggal_peminjaman) {
        this.tanggal_peminjaman = tanggal_peminjaman;
    }

    public Date getTanggal_kembali() {
        return tanggal_kembali;
    }

    public void setTanggal_kembali(Date tanggal_kembali) {
        this.tanggal_kembali = tanggal_kembali;
    }

    public int getBarangKode_brg() {
        return barangKode_brg;
    }

    public void setBarangKode_brg(int barangKode_brg) {
        this.barangKode_brg = barangKode_brg;
    }

    public int getKuantitas() {
        return Kuantitas;
    }

    public void setKuantitas(int Kuantitas) {
        this.Kuantitas = Kuantitas;
    }

    public int getMahasiswaNIM_mhs() {
        return mahasiswaNIM_mhs;
    }

    public void setMahasiswaNIM_mhs(int mahasiswaNIM_mhs) {
        this.mahasiswaNIM_mhs = mahasiswaNIM_mhs;
    }

    public String getStatus_peminjaman() {
        return Status_peminjaman;
    }

    public void setStatus_peminjaman(String Status_peminjaman) {
        this.Status_peminjaman = Status_peminjaman;
    }
    
    public void updateStatusPeminjaman(int idPeminjaman, String statusBaru) {
        try {
            String query = "UPDATE peminjaman SET Status_peminjaman = ? WHERE ID_Peminjaman = ?";
            Database.preparedStatement = Database.connection.prepareStatement(query);
            Database.preparedStatement.setString(1, statusBaru);
            Database.preparedStatement.setInt(2, idPeminjaman);

            int rowsUpdated = Database.preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Status peminjaman berhasil diperbarui!");
            }
        } catch (Exception e) {
            System.err.println("Error updating peminjaman: " + e.getMessage());
        }
    }
}
