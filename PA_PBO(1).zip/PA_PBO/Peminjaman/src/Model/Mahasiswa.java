package Model;

import java.util.ArrayList;
import java.util.List;

public abstract class Mahasiswa {
    String nim;
    private String nama;
    private String noTelp;
    private List<Peminjaman> peminjamanList; // Daftar peminjaman mahasiswa

    // Konstruktor
    public Mahasiswa(String nim, String nama, String noTelp) {
        this.nim = nim;
        this.nama = nama;
        this.noTelp = noTelp;
    }

    // Getter dan Setter
    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNoTelp() {
        return noTelp;
    }

    public void setNoTelp(String noTelp) {
        this.noTelp = noTelp;
    }

    public List<Peminjaman> getPeminjamanList() {
        return peminjamanList;
    }

    public void setPeminjamanList(List<Peminjaman> peminjamanList) {
        this.peminjamanList = peminjamanList;
    }

    // Metode tambahan
    public abstract String getRoleDescription(); // Menjadikan metode ini abstrak

    // Menambahkan peminjaman
    public void tambahPeminjaman(Peminjaman peminjaman) {
        if (peminjamanList == null) {
            peminjamanList = new ArrayList<>();
        }
        peminjamanList.add(peminjaman);
    }
}
