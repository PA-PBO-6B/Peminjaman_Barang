/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package GUI;
import Model.Barang;
import Database.Database;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class BarangAdmin extends javax.swing.JPanel {

    /**
     * Creates new form BukuAdmin
     */
    public BarangAdmin() {
        initComponents();
        Database.connect();
        tabel();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Main = new javax.swing.JPanel();
        DaftarBarang = new javax.swing.JPanel();
        btnTambah = new javax.swing.JButton();
        btnDeleteBarang = new javax.swing.JButton();
        btnUpdateBarang = new javax.swing.JButton();
        comboBoxSorting = new javax.swing.JComboBox<>();
        txtFieldSearchDaftar = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelBarang = new javax.swing.JTable();
        TambahBarang = new javax.swing.JPanel();
        btnTambahBarang = new javax.swing.JButton();
        btnKembaliBarang = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txtFieldJenisTambah = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtFieldKodeTambah = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtFieldSpekTambah = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtFieldStokTambah = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        comboBoxStatus = new javax.swing.JComboBox<>();
        UpdateBarang = new javax.swing.JPanel();
        btnUpdate = new javax.swing.JButton();
        btnKembali = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txtFieldJenisUpdate = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtFieldKodeUpdate = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtFieldSpekUpdate = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtFieldStokUpdate = new javax.swing.JTextField();
        comboBoxStatus1 = new javax.swing.JComboBox<>();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new java.awt.CardLayout());

        Main.setBackground(new java.awt.Color(255, 255, 255));
        Main.setLayout(new java.awt.CardLayout());

        DaftarBarang.setBackground(new java.awt.Color(255, 255, 255));

        btnTambah.setBackground(new java.awt.Color(0, 204, 0));
        btnTambah.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnTambah.setText("Tambah");
        btnTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahActionPerformed(evt);
            }
        });

        btnDeleteBarang.setBackground(new java.awt.Color(255, 0, 51));
        btnDeleteBarang.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnDeleteBarang.setText("Delete");
        btnDeleteBarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteBarangActionPerformed(evt);
            }
        });

        btnUpdateBarang.setBackground(new java.awt.Color(255, 153, 51));
        btnUpdateBarang.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnUpdateBarang.setText("Update");
        btnUpdateBarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateBarangActionPerformed(evt);
            }
        });

        comboBoxSorting.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Kode(Asc)", "Kode(Desc)", "Jenis(A-Z)", "Jenis(Z-A)" }));
        comboBoxSorting.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxSortingActionPerformed(evt);
            }
        });

        txtFieldSearchDaftar.setText("Search");
        txtFieldSearchDaftar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFieldSearchDaftarActionPerformed(evt);
            }
        });
        txtFieldSearchDaftar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtFieldSearchDaftarKeyReleased(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setText("Daftar Barang");

        tabelBarang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Kode Barang", "Jenis Barang", "Spesifikasi Barang ", "Stok Barang", "Status Barang"
            }
        ));
        tabelBarang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelBarangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabelBarang);

        javax.swing.GroupLayout DaftarBarangLayout = new javax.swing.GroupLayout(DaftarBarang);
        DaftarBarang.setLayout(DaftarBarangLayout);
        DaftarBarangLayout.setHorizontalGroup(
            DaftarBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DaftarBarangLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(DaftarBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 622, Short.MAX_VALUE)
                    .addGroup(DaftarBarangLayout.createSequentialGroup()
                        .addGroup(DaftarBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(DaftarBarangLayout.createSequentialGroup()
                                .addComponent(comboBoxSorting, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtFieldSearchDaftar, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(DaftarBarangLayout.createSequentialGroup()
                                .addGap(164, 164, 164)
                                .addComponent(btnTambah)
                                .addGap(18, 18, 18)
                                .addComponent(btnUpdateBarang)
                                .addGap(18, 18, 18)
                                .addComponent(btnDeleteBarang)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        DaftarBarangLayout.setVerticalGroup(
            DaftarBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, DaftarBarangLayout.createSequentialGroup()
                .addContainerGap(11, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(DaftarBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboBoxSorting, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFieldSearchDaftar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(DaftarBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnDeleteBarang)
                    .addComponent(btnUpdateBarang)
                    .addComponent(btnTambah))
                .addGap(46, 46, 46))
        );

        Main.add(DaftarBarang, "card2");

        TambahBarang.setBackground(new java.awt.Color(255, 255, 255));

        btnTambahBarang.setBackground(new java.awt.Color(0, 204, 0));
        btnTambahBarang.setText("Tambah");
        btnTambahBarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahBarangActionPerformed(evt);
            }
        });

        btnKembaliBarang.setBackground(new java.awt.Color(255, 0, 51));
        btnKembaliBarang.setText("Kembali");
        btnKembaliBarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKembaliBarangActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setText("Tambah Barang");

        jLabel3.setText("Kode Barang");

        jLabel4.setText("Jenis Barang");

        jLabel5.setText("Spesifikasi Barang");

        txtFieldSpekTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFieldSpekTambahActionPerformed(evt);
            }
        });

        jLabel13.setText("Stok Barang");

        txtFieldStokTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFieldStokTambahActionPerformed(evt);
            }
        });

        jLabel14.setText("Status Barang");

        comboBoxStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Status", "Tersedia", "Tidak ada" }));

        javax.swing.GroupLayout TambahBarangLayout = new javax.swing.GroupLayout(TambahBarang);
        TambahBarang.setLayout(TambahBarangLayout);
        TambahBarangLayout.setHorizontalGroup(
            TambahBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TambahBarangLayout.createSequentialGroup()
                .addGroup(TambahBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtFieldKodeTambah)
                    .addGroup(TambahBarangLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(TambahBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtFieldSpekTambah)
                            .addComponent(txtFieldJenisTambah)
                            .addComponent(txtFieldStokTambah)
                            .addGroup(TambahBarangLayout.createSequentialGroup()
                                .addGroup(TambahBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(TambahBarangLayout.createSequentialGroup()
                                        .addComponent(btnTambahBarang)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnKembaliBarang))
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel14)
                                    .addComponent(jLabel13)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(comboBoxStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 435, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        TambahBarangLayout.setVerticalGroup(
            TambahBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TambahBarangLayout.createSequentialGroup()
                .addContainerGap(29, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(TambahBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTambahBarang)
                    .addComponent(btnKembaliBarang))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFieldKodeTambah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFieldJenisTambah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFieldSpekTambah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFieldStokTambah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comboBoxStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46))
        );

        Main.add(TambahBarang, "card2");

        UpdateBarang.setBackground(new java.awt.Color(255, 255, 255));

        btnUpdate.setBackground(new java.awt.Color(255, 102, 0));
        btnUpdate.setText("Update");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        btnKembali.setBackground(new java.awt.Color(255, 0, 51));
        btnKembali.setText("Kembali");
        btnKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKembaliActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel7.setText("Update Barang");

        jLabel8.setText("Kode Barang");

        jLabel9.setText("Jenis Barang");

        jLabel10.setText("Spesifikasi Barang");

        jLabel11.setText("Status Barang");

        jLabel12.setText("Stok Barang");

        comboBoxStatus1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Status", "Tersedia", "Tidak ada" }));

        javax.swing.GroupLayout UpdateBarangLayout = new javax.swing.GroupLayout(UpdateBarang);
        UpdateBarang.setLayout(UpdateBarangLayout);
        UpdateBarangLayout.setHorizontalGroup(
            UpdateBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UpdateBarangLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(UpdateBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtFieldSpekUpdate)
                    .addComponent(txtFieldJenisUpdate)
                    .addComponent(txtFieldStokUpdate)
                    .addComponent(txtFieldKodeUpdate, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(UpdateBarangLayout.createSequentialGroup()
                        .addGroup(UpdateBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(UpdateBarangLayout.createSequentialGroup()
                                .addComponent(btnUpdate)
                                .addGap(18, 18, 18)
                                .addComponent(btnKembali))
                            .addComponent(jLabel8)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11)
                            .addComponent(jLabel12)
                            .addComponent(jLabel7)
                            .addComponent(comboBoxStatus1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 368, Short.MAX_VALUE)))
                .addContainerGap())
        );
        UpdateBarangLayout.setVerticalGroup(
            UpdateBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, UpdateBarangLayout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(UpdateBarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnUpdate)
                    .addComponent(btnKembali))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFieldKodeUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFieldJenisUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFieldSpekUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFieldStokUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(comboBoxStatus1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46))
        );

        Main.add(UpdateBarang, "card2");

        add(Main, "card2");
    }// </editor-fold>//GEN-END:initComponents
    
    private void tabel(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Kode Barang");
        model.addColumn("Jenis Barang");
        model.addColumn("Spesifikasi Barang");
        model.addColumn("Stok Barang");
        model.addColumn("Status Barang");
        try {
            Statement statement = Database.connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM barang");

            while (resultSet.next()) {
                model.addRow(new Object[] {
                    resultSet.getString("Kode_brg"),
                    resultSet.getString("Jenis_brg"),
                    resultSet.getString("Spesifikasi_brg"),
                    resultSet.getInt("Stok_brg"),
                    resultSet.getString("Status_brg"),
                });
                tabelBarang.setModel(model);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal memuat data!");
        }
    }
    
    private void clearText(){
        txtFieldKodeTambah.setText("");
        txtFieldJenisTambah.setText("");
        txtFieldSpekTambah.setText("");
        txtFieldStokTambah.setText("");
        comboBoxStatus.setSelectedIndex(0);
    }
    
    private void btnTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahActionPerformed
        Main.removeAll(); // Menghapus semua komponen
        Main.add( TambahBarang);
        Main.revalidate(); // Memastikan layout diperbarui
        Main.repaint(); // Memperbarui tampilan
    }//GEN-LAST:event_btnTambahActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        try {
        // Mengambil data dari textfield untuk diupdate
            int kodeBarang = Integer.parseInt(txtFieldKodeUpdate.getText());
            String jenisBarang = txtFieldJenisUpdate.getText();
            String spesifikasiBarang = txtFieldSpekUpdate.getText();
            int stokBarang = Integer.parseInt(txtFieldStokUpdate.getText());
            String statusBarang = comboBoxStatus1.getSelectedItem().toString();

            // Validasi input statusBarang
            if (statusBarang.equals("Pilih Status")) {
                JOptionPane.showMessageDialog(null, "Tolong isi semua kolom");
            } else {
                // Membuat objek Barang dengan data yang diambil dari textfield
                Barang barang = new Barang(kodeBarang, jenisBarang, spesifikasiBarang, stokBarang, statusBarang);

                // Memanggil method untuk update barang
                barang.updateBarang();

                // Memperbarui tampilan tabel
                tabel(); 
                clearText(); // Mengosongkan textfield
            }
        } catch (Exception e) {
            // Menampilkan pesan jika terjadi error
            JOptionPane.showMessageDialog(null, "Terjadi Kesalahan");
            e.printStackTrace();
    }
    
     
        Main.removeAll(); // Menghapus semua komponen
        Main.add( DaftarBarang);
        Main.revalidate(); // Memastikan layout diperbarui
        Main.repaint(); // Memperbarui tampilan
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void txtFieldSpekTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFieldSpekTambahActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFieldSpekTambahActionPerformed

    private void btnTambahBarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahBarangActionPerformed
        try {
            if (Database.connect() != null) {
                int kodeBarang = Integer.parseInt(txtFieldKodeTambah.getText());
                String jenisBarang = txtFieldJenisTambah.getText();
                String spesifikasiBarang = txtFieldSpekTambah.getText();
                int stokBarang = Integer.parseInt(txtFieldStokTambah.getText());
                String statusBarang = comboBoxStatus.getSelectedItem().toString();
                
                
                if (statusBarang.equals("Pilih Status")) {
                    JOptionPane.showMessageDialog(null, "Pilih status dengan benar!");
                } else {
                    Barang barang = new Barang(kodeBarang, jenisBarang, spesifikasiBarang, stokBarang, statusBarang);
                    barang.tambahBarang();
                    tabel();
                    clearText();
 
                }
            } else {
                JOptionPane.showMessageDialog(null, "Database belum konek!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Terjadi Kesalahan!" + e.getMessage());
        }
        Main.removeAll(); // Menghapus semua komponen
        Main.add( DaftarBarang);
        Main.revalidate(); // Memastikan layout diperbarui
        Main.repaint(); // Memperbarui tampilan
    }//GEN-LAST:event_btnTambahBarangActionPerformed

    private void txtFieldStokTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFieldStokTambahActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFieldStokTambahActionPerformed

    private void btnUpdateBarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateBarangActionPerformed
        int selectedRow = tabelBarang.getSelectedRow(); 
        if (selectedRow != -1) { // Pastikan ada baris yang dipilih
        // Ambil data dari tabel berdasarkan kolom
            int kodeBarang = Integer.parseInt(tabelBarang.getValueAt(selectedRow, 0).toString());
            String jenisBarang = tabelBarang.getValueAt(selectedRow, 1).toString();
            String spesifikasiBarang = tabelBarang.getValueAt(selectedRow, 2).toString();
            int stokBarang = Integer.parseInt(tabelBarang.getValueAt(selectedRow, 3).toString());
            String statusBarang = tabelBarang.getValueAt(selectedRow, 4).toString();

            // Kirim data ini ke panel UpdateBarang
            txtFieldKodeUpdate.setText(String.valueOf(kodeBarang));
            txtFieldJenisUpdate.setText(jenisBarang);
            txtFieldSpekUpdate.setText(spesifikasiBarang);
            txtFieldStokUpdate.setText(String.valueOf(stokBarang));
            comboBoxStatus1.setSelectedItem(statusBarang);
            Main.removeAll(); // Menghapus semua komponen
            Main.add( UpdateBarang);
            Main.revalidate(); // Memastikan layout diperbarui
            Main.repaint(); // Memperbarui tampilan
            } else {
            // Menampilkan pesan jika tidak ada baris yang dipilih
            JOptionPane.showMessageDialog(null, "Tolong pilih baris terlebih dahulu.");
        }
    }//GEN-LAST:event_btnUpdateBarangActionPerformed

    private void btnKembaliBarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKembaliBarangActionPerformed
        Main.removeAll(); // Menghapus semua komponen
        Main.add( DaftarBarang);
        Main.revalidate(); // Memastikan layout diperbarui
        Main.repaint(); // Memperbarui tampilan
    }//GEN-LAST:event_btnKembaliBarangActionPerformed

    private void btnKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKembaliActionPerformed
        Main.removeAll(); // Menghapus semua komponen
        Main.add( DaftarBarang);
        Main.revalidate(); // Memastikan layout diperbarui
        Main.repaint(); // Memperbarui tampilan
    }//GEN-LAST:event_btnKembaliActionPerformed

    private void btnDeleteBarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteBarangActionPerformed
        try {
            int row = tabelBarang.getSelectedRow();

            if (row == -1) {
                JOptionPane.showMessageDialog(null, "Silahkan pilih baris yang akan dihapus");
            } else {
                DefaultTableModel model = (DefaultTableModel) tabelBarang.getModel();
                int kodeBarang = Integer.parseInt(tabelBarang.getValueAt(row, 0).toString());
                Barang barang = new Barang(0, "", "", 0, "");
                barang.setKodeBarang(kodeBarang);
                barang.deleteBarang();
                model.removeRow(row);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Terjadi Kesalahan");
            e.printStackTrace();
        }// TODO add your handling code here:
    }//GEN-LAST:event_btnDeleteBarangActionPerformed

    private void tabelBarangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelBarangMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tabelBarangMouseClicked

    private void txtFieldSearchDaftarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtFieldSearchDaftarKeyReleased
        String keyword = txtFieldSearchDaftar.getText(); // Ambil teks dari JTextField
        try {
            String query = "SELECT * FROM barang WHERE Jenis_brg LIKE ? OR Spesifikasi_brg LIKE ?";
            Database.preparedStatement = Database.connection.prepareStatement(query);
            Database.preparedStatement.setString(1, "%" + keyword + "%");
            Database.preparedStatement.setString(2, "%" + keyword + "%");
            ResultSet resultSet = Database.preparedStatement.executeQuery();

            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Kode Barang");
            model.addColumn("Jenis Barang");
            model.addColumn("Spesifikasi");
            model.addColumn("Stok");
            model.addColumn("Status");

            while (resultSet.next()) {
                Vector<String> row = new Vector<>();
                row.add(resultSet.getString("Kode_brg"));
                row.add(resultSet.getString("Jenis_brg"));
                row.add(resultSet.getString("Spesifikasi_brg"));
                row.add(resultSet.getString("Stok_brg"));
                row.add(resultSet.getString("Status_brg"));
                model.addRow(row);
            }
            tabelBarang.setModel(model); // Tampilkan data di tabel
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal mencari barang: " + e.getMessage());
        }// TODO add your handling code here:
    }//GEN-LAST:event_txtFieldSearchDaftarKeyReleased

    private void comboBoxSortingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxSortingActionPerformed
        String selectedSort = (String) comboBoxSorting.getSelectedItem(); // Ambil pilihan dari combo box
        String query = "";

        // Tentukan query berdasarkan pilihan
        if ("Kode(Asc)".equals(selectedSort)) {
            query = "SELECT * FROM barang ORDER BY Kode_brg ASC";
        } else if ("Kode(Desc)".equals(selectedSort)) {
            query = "SELECT * FROM barang ORDER BY Kode_brg DESC";
        } else if ("Jenis(A-Z)".equals(selectedSort)) {
            query = "SELECT * FROM barang ORDER BY Jenis_brg ASC";
        } else if ("Jenis(Z-A)".equals(selectedSort)) {
            query = "SELECT * FROM barang ORDER BY Jenis_brg DESC";
        }

        // Eksekusi query dan tampilkan data
        try {
            Database.preparedStatement = Database.connection.prepareStatement(query);
            ResultSet resultSet = Database.preparedStatement.executeQuery();

            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Kode Barang");
            model.addColumn("Jenis Barang");
            model.addColumn("Spesifikasi");
            model.addColumn("Stok");
            model.addColumn("Status");

            while (resultSet.next()) {
                Vector<String> row = new Vector<>();
                row.add(resultSet.getString("Kode_brg"));
                row.add(resultSet.getString("Jenis_brg"));
                row.add(resultSet.getString("Spesifikasi_brg"));
                row.add(resultSet.getString("Stok_brg"));
                row.add(resultSet.getString("Status_brg"));
                model.addRow(row);
            }
            tabelBarang.setModel(model); // Tampilkan data di tabel
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal mengurutkan data: " + e.getMessage());
        }// TODO add your handling code here:
    }//GEN-LAST:event_comboBoxSortingActionPerformed

    private void txtFieldSearchDaftarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFieldSearchDaftarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFieldSearchDaftarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel DaftarBarang;
    private javax.swing.JPanel Main;
    private javax.swing.JPanel TambahBarang;
    private javax.swing.JPanel UpdateBarang;
    private javax.swing.JButton btnDeleteBarang;
    private javax.swing.JButton btnKembali;
    private javax.swing.JButton btnKembaliBarang;
    private javax.swing.JButton btnTambah;
    private javax.swing.JButton btnTambahBarang;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JButton btnUpdateBarang;
    private javax.swing.JComboBox<String> comboBoxSorting;
    private javax.swing.JComboBox<String> comboBoxStatus;
    private javax.swing.JComboBox<String> comboBoxStatus1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelBarang;
    private javax.swing.JTextField txtFieldJenisTambah;
    private javax.swing.JTextField txtFieldJenisUpdate;
    private javax.swing.JTextField txtFieldKodeTambah;
    private javax.swing.JTextField txtFieldKodeUpdate;
    private javax.swing.JTextField txtFieldSearchDaftar;
    private javax.swing.JTextField txtFieldSpekTambah;
    private javax.swing.JTextField txtFieldSpekUpdate;
    private javax.swing.JTextField txtFieldStokTambah;
    private javax.swing.JTextField txtFieldStokUpdate;
    // End of variables declaration//GEN-END:variables
}
