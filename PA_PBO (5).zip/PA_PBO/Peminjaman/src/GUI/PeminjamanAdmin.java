/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package GUI;
import java.sql.Connection;
import Database.Database;
import Model.Peminjaman;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.Vector;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author LENOVO
 */
public class PeminjamanAdmin extends javax.swing.JPanel {

    /**
     * Creates new form PeminjamanAdmin
     */
    public PeminjamanAdmin() {
        initComponents();
        Database.connect();
        tabel();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        main = new javax.swing.JPanel();
        DaftarPeminjaman = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelPinjam = new javax.swing.JTable();
        btnUpdate = new javax.swing.JButton();
        comboBoxSortingPeminjaman = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        UpdatePeminjaman = new javax.swing.JPanel();
        btnUpdatePinjam = new javax.swing.JButton();
        btnKembali = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtFieldIDPinjam = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        comboBoxStatusPinjam = new javax.swing.JComboBox<>();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new java.awt.CardLayout());

        main.setBackground(new java.awt.Color(255, 255, 255));
        main.setLayout(new java.awt.CardLayout());

        DaftarPeminjaman.setBackground(new java.awt.Color(255, 255, 255));

        tabelPinjam.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tabelPinjam);

        btnUpdate.setBackground(new java.awt.Color(255, 102, 0));
        btnUpdate.setText("Update");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        comboBoxSortingPeminjaman.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Status", "Menunggu", "Diterima", "Ditolak", "Selesai", " " }));
        comboBoxSortingPeminjaman.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboBoxSortingPeminjamanActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setText("Peminjaman");

        javax.swing.GroupLayout DaftarPeminjamanLayout = new javax.swing.GroupLayout(DaftarPeminjaman);
        DaftarPeminjaman.setLayout(DaftarPeminjamanLayout);
        DaftarPeminjamanLayout.setHorizontalGroup(
            DaftarPeminjamanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DaftarPeminjamanLayout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addGroup(DaftarPeminjamanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 642, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnUpdate)
                    .addComponent(comboBoxSortingPeminjaman, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        DaftarPeminjamanLayout.setVerticalGroup(
            DaftarPeminjamanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, DaftarPeminjamanLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnUpdate)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(comboBoxSortingPeminjaman, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, 18, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        main.add(DaftarPeminjaman, "card2");

        UpdatePeminjaman.setBackground(new java.awt.Color(255, 255, 255));

        btnUpdatePinjam.setBackground(new java.awt.Color(255, 102, 0));
        btnUpdatePinjam.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnUpdatePinjam.setText("Update");
        btnUpdatePinjam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdatePinjamActionPerformed(evt);
            }
        });

        btnKembali.setBackground(new java.awt.Color(204, 204, 204));
        btnKembali.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnKembali.setText("< Back");
        btnKembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKembaliActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Peminjaman");

        jLabel3.setText("Id Peminjaman");

        jLabel6.setText("Status Peminjaman");

        comboBoxStatusPinjam.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Status", "Menunggu", "Diterima", "Ditolak", "Selesai" }));

        javax.swing.GroupLayout UpdatePeminjamanLayout = new javax.swing.GroupLayout(UpdatePeminjaman);
        UpdatePeminjaman.setLayout(UpdatePeminjamanLayout);
        UpdatePeminjamanLayout.setHorizontalGroup(
            UpdatePeminjamanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UpdatePeminjamanLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(UpdatePeminjamanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtFieldIDPinjam, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addGroup(UpdatePeminjamanLayout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(btnKembali)
                        .addGap(18, 18, 18)
                        .addComponent(btnUpdatePinjam))
                    .addComponent(comboBoxStatusPinjam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(456, Short.MAX_VALUE))
        );
        UpdatePeminjamanLayout.setVerticalGroup(
            UpdatePeminjamanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UpdatePeminjamanLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFieldIDPinjam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comboBoxStatusPinjam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17)
                .addGroup(UpdatePeminjamanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnKembali)
                    .addComponent(btnUpdatePinjam))
                .addContainerGap(219, Short.MAX_VALUE))
        );

        main.add(UpdatePeminjaman, "card2");

        add(main, "card2");
    }// </editor-fold>//GEN-END:initComponents
    private void tabel(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID Peminjaman");
        model.addColumn("Kode Barang");
        model.addColumn("Kuantitas");
        model.addColumn("NIM");
        model.addColumn("Tanggal pinjam");
        model.addColumn("Tanggal Kembali");
        model.addColumn("Status");
        try {
            Statement statement = Database.connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM peminjaman");

            while (resultSet.next()) {
                model.addRow(new Object[] {
                    resultSet.getInt("ID_Peminjaman"),
                    resultSet.getInt("Kode_brg"),
                    resultSet.getInt("Stok_brg"),
                    resultSet.getString("NIM_mhs"),
                    resultSet.getDate("tanggal_pinjam"),
                    resultSet.getDate("tanggal_kembali"),
                    resultSet.getString("Status_peminjaman"),
                });
                tabelPinjam.setModel(model);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal memuat data!");
        }
    }
    
    private void btnUpdatePinjamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdatePinjamActionPerformed
        try {
            int idPeminjaman = Integer.parseInt(txtFieldIDPinjam.getText());
            String status = comboBoxStatusPinjam.getSelectedItem().toString();

           
            if (status.equals("Pilih Status")) {
                JOptionPane.showMessageDialog(null, "Silakan pilih status yang valid.");
                return;
            }

            
            String query = "UPDATE peminjaman SET Status_peminjaman = ? WHERE ID_Peminjaman = ?";
            PreparedStatement ps = Database.connection.prepareStatement(query);
            ps.setString(1, status);
            ps.setInt(2, idPeminjaman);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Status berhasil diperbarui!");
        
            main.removeAll(); 
            main.add( DaftarPeminjaman);
            main.revalidate(); 
            main.repaint(); 
            tabel();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal memperbarui status: " + e.getMessage());
            e.printStackTrace();
        }
            
    }//GEN-LAST:event_btnUpdatePinjamActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        int selectedRow = tabelPinjam.getSelectedRow(); 
        if (selectedRow != -1) {
        
        int idPeminjaman = (int) tabelPinjam.getValueAt(selectedRow, 0); 
        String kodeBarang = tabelPinjam.getValueAt(selectedRow, 1).toString(); 
        String NIMpeminjam = tabelPinjam.getValueAt(selectedRow, 4).toString(); 
        String status = tabelPinjam.getValueAt(selectedRow, 6).toString(); 

        
        txtFieldIDPinjam.setText(String.valueOf(idPeminjaman));
        comboBoxStatusPinjam.setSelectedItem(status);
    
        main.removeAll();
        main.add(UpdatePeminjaman);
        main.revalidate();
        main.repaint();
    } else {
        JOptionPane.showMessageDialog(null, "Silakan pilih baris terlebih dahulu!");
    }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKembaliActionPerformed
        main.removeAll(); 
        main.add( DaftarPeminjaman);
        main.revalidate(); 
        main.repaint(); 
    }//GEN-LAST:event_btnKembaliActionPerformed

    private void comboBoxSortingPeminjamanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboBoxSortingPeminjamanActionPerformed
        String selectedStatus = (String) comboBoxSortingPeminjaman.getSelectedItem(); 
        String query = "";

        // Tentukan query berdasarkan pilihan status
        if ("Pilih Status".equals(selectedStatus)) {
        query = "SELECT * FROM peminjaman"; 
        } else if ("Menunggu".equals(selectedStatus)) {
            query = "SELECT * FROM peminjaman WHERE Status_peminjaman = 'Menunggu'";
        } else if ("Ditolak".equals(selectedStatus)) {
            query = "SELECT * FROM peminjaman WHERE Status_peminjaman = 'Ditolak'";
        } else if ("Diterima".equals(selectedStatus)) {
            query = "SELECT * FROM peminjaman WHERE Status_peminjaman = 'Diterima'";
        } else if ("Selesai".equals(selectedStatus)) {
            query = "SELECT * FROM peminjaman WHERE Status_peminjaman = 'Selesai'";
        }

        
        try {
            Connection conn = Database.connect();
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet resultSet = stmt.executeQuery();

            
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("ID Peminjaman");
            model.addColumn("Kode Barang");
            model.addColumn("Kuantitas");
            model.addColumn("NIM Mahasiswa");
            model.addColumn("Tanggal Pinjam");
            model.addColumn("Tanggal Kembali");
            model.addColumn("Status Peminjaman");

            
            while (resultSet.next()) {
                model.addRow(new Object[]{
                    resultSet.getInt("ID_peminjaman"),
                    resultSet.getInt("Kode_brg"),
                    resultSet.getInt("Stok_brg"),
                    resultSet.getString("NIM_mhs"),
                    resultSet.getDate("tanggal_pinjam"),
                    resultSet.getDate("tanggal_kembali"),
                    resultSet.getString("Status_peminjaman")
                });
            }

            
            tabelPinjam.setModel(model);

            stmt.close();
            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal memfilter data peminjaman: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_comboBoxSortingPeminjamanActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel DaftarPeminjaman;
    private javax.swing.JPanel UpdatePeminjaman;
    private javax.swing.JButton btnKembali;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JButton btnUpdatePinjam;
    private javax.swing.JComboBox<String> comboBoxSortingPeminjaman;
    private javax.swing.JComboBox<String> comboBoxStatusPinjam;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel main;
    private javax.swing.JTable tabelPinjam;
    private javax.swing.JTextField txtFieldIDPinjam;
    // End of variables declaration//GEN-END:variables
}
