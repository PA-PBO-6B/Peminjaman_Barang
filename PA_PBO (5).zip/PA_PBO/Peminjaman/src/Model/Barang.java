/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;
import Database.Database;
import javax.swing.JOptionPane;

public class Barang {
    private int kodeBarang;
    private String jenisBarang;
    private String spesifikasiBarang;
    private int stokBarang;
    private String statusBarang;

    public Barang(int kodeBarang, String jenisBarang, String spesifikasiBarang, int stokBarang, String statusBarang) {
        this.kodeBarang = kodeBarang;
        this.jenisBarang = jenisBarang;
        this.spesifikasiBarang = spesifikasiBarang;
        this.stokBarang = stokBarang;
        this.statusBarang = statusBarang;
    }


    // Getter dan Setter

    public int getKodeBarang() {
        return kodeBarang;
    }

    public void setKodeBarang(int kodeBarang) {
        this.kodeBarang = kodeBarang;
    }

    
    public String getJenisBarang() {
        return jenisBarang;
    }

    public void setJenisBarang(String jenisBarang) {
        this.jenisBarang = jenisBarang;
    }

    public String getSpesifikasiBarang() {
        return spesifikasiBarang;
    }

    public void setSpesifikasiBarang(String spesifikasiBarang) {
        this.spesifikasiBarang = spesifikasiBarang;
    }

    public int getStokBarang() {
        return stokBarang;
    }

    public void setStokBarang(int stokBarang) {
        this.stokBarang = stokBarang;
    }

    public String getStatusBarang() {
        return statusBarang;
    }

    public void setStatusBarang(String statusBarang) {
        this.statusBarang = statusBarang;
    }

    public void tambahBarang(){
        try {
            String query = "INSERT INTO barang (Kode_brg, Jenis_brg, Spesifikasi_brg, Stok_brg, Status_brg) VALUES (?, ?, ?, ?, ?)";
            Database.preparedStatement = Database.connection.prepareStatement(query);
            Database.preparedStatement.setInt(1, this.getKodeBarang());
            Database.preparedStatement.setString(2, this.getJenisBarang());
            Database.preparedStatement.setString(3, this.getSpesifikasiBarang());
            Database.preparedStatement.setInt(4, this.getStokBarang());
            Database.preparedStatement.setString(5, this.getStatusBarang());
            Database.preparedStatement.executeUpdate();
            JOptionPane.showMessageDialog(null, "Berhasil menambah data!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal menambah data!" + e.getMessage());
        }
    }
    public final void deleteBarang() {
        try {
            String query = "DELETE FROM barang WHERE Kode_brg = ?";
            Database.preparedStatement = Database.connection.prepareStatement(query);
            Database.preparedStatement.setInt(1, this.getKodeBarang());
            Database.preparedStatement.executeUpdate();
            JOptionPane.showMessageDialog(null, "Berhasil menghapus data!");
        } catch (Exception e) {
           JOptionPane.showMessageDialog(null, "Gagal menghapus data!" + e.getMessage());
        }
    }

    public final void updateBarang() {
        try {
            String query = "UPDATE barang SET Jenis_brg = ?, Spesifikasi_brg = ?, Stok_brg = ?, Status_brg = ? WHERE Kode_brg = ?";
            Database.preparedStatement = Database.connection.prepareStatement(query);
            Database.preparedStatement.setString(1, this.getJenisBarang());
            Database.preparedStatement.setString(2, this.getSpesifikasiBarang());
            Database.preparedStatement.setInt(3, this.getStokBarang());
            Database.preparedStatement.setString(4, this.getStatusBarang());
            Database.preparedStatement.setInt(5, this.getKodeBarang());
            Database.preparedStatement.executeUpdate();
            JOptionPane.showMessageDialog(null, "Berhasil mengubah data!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal mengubah data!" + e.getMessage());
        }
    }
}