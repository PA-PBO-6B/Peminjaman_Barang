/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;
import Database.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 *
 * @author LENOVO
 */
public class AdminBiro extends Mahasiswa {
    private String Jabatan_fungsi;

    // Konstruktor
    public AdminBiro(String nim, String nama, String noTelp,
            String jabatan) {
        super(nim, nama, noTelp);
        this.Jabatan_fungsi = jabatan;
    }

    // Getter dan Setter
    public String getJabatanFungsi() {
        return Jabatan_fungsi;
    }

    public void setJabatanFungsi(String jabatan) {
        this.Jabatan_fungsi = jabatan;
    }

    // Static method untuk memuat data dari database
    public static AdminBiro loadData(String NIM_mhs) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = Database.connect();
            String query = "SELECT * FROM admin_biro WHERE NIM_mhs = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, NIM_mhs);

            rs = stmt.executeQuery();
            if (rs.next()) {
                String nim = rs.getString("NIM_mhs");
                String nama = rs.getString("Nama_mhs");
                String noTelp = rs.getString("no_telp_mhs");
                String jabatan = rs.getString("Jabatan_fungsi");

                return new AdminBiro(nim, nama, noTelp, jabatan);
            } else {
                throw new SQLException("Data tidak ditemukan untuk NIM: " + NIM_mhs);
            }
        } catch (SQLException e) {
            System.err.println("SQL Error: " + e.getMessage());
            e.printStackTrace();
            return null;
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("Gagal menutup sumber daya: " + e.getMessage());
            }
        }
    }

    @Override
    public String getRoleDescription() {
        return "Admin Biro bertugas mengelola biro terkait dengan jabatan: " + Jabatan_fungsi;
    }
}
